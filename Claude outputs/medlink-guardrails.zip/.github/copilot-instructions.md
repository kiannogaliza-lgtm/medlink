# MedLink - rules for GitHub Copilot (agent mode)

Project: MedLink, Laravel 13 + Vue 3, Barangay Honrado Health Center. Folder `C:\laragon\www\techyknowloadeia1`.

## Approval gates (never skip)
- **Before ANY file write**: show a per-file summary (file, what changes, why) and wait for the developer to reply `APPROVED`. One approval covers only the files listed in that summary.
- **Before ANY database command** (`php artisan migrate`, `migrate:rollback`, `db:seed`, `tinker`, `mysql ...`): stop and ask. Show the exact command and the `php artisan migrate --pretend` output first. Never run them in the same step as the request.
- **Never run**: `migrate:fresh`, `migrate:refresh`, `migrate:reset`, `db:wipe`, `DROP`, `TRUNCATE`, `git push`, anything that prints `.env` values, anything that deletes `storage/app`, `public/storage`, migrations or `.env`.
- Never edit `.env`, `vendor/`, `node_modules/`, `public/build/`, uploads, `.claude/`, `.vscode/settings.json` or this file.
- Never edit an existing migration; create a new one.
- Before a real migrate, confirm a backup newer than 60 minutes exists in `C:\laragon-backups\` (`dir C:\laragon-backups`). If not, stop and ask the developer to back up.
- `git commit` only when the developer says so.

## Automatic checks (run after every change, report results)
- `php -l <file>` for every edited PHP file.
- `node --check <file>` for edited plain `.js` files.
- `php artisan migrate --pretend` after creating a migration.
- `php artisan route:list` after editing `routes/web.php`.
- `npm run build` after editing anything in `resources/js` or `.vue` files.
- Tests: `php artisan test` only while `phpunit.xml` keeps `DB_CONNECTION=sqlite` and `DB_DATABASE=:memory:`. Never point tests at MySQL. Fake httpSMS with `Http::fake()`.
- If a check fails, fix it before moving on. Never report something as tested unless the command actually ran.

## House rules
- Phone numbers: Philippine mobiles only (`09XXXXXXXXX` / `+639XXXXXXXXX`), stored as `09...`; use the shared `PhilippineMobile` rule, not a copied regex.
- Never log OTP codes, passwords, SMS bodies, API keys or health data.
- Keep existing `AppNotification` and `AccountLog::record` calls; SMS is an extra channel.
- Phases run as Step A (read-only plan, wait) -> Step B (summary, approval, edit) -> Step C (checks + manual test list).
