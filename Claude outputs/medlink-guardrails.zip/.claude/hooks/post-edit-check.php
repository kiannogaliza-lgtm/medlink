<?php
// PostToolUse (Edit|Write|MultiEdit): automatic checks after every approved write.
// A failure is sent back to Claude (exit 2) so it fixes the file before moving on.
require __DIR__ . '/_lib.php';

$in = hook_input();
$project = project_dir($in);
$file = (string) ($in['tool_input']['file_path'] ?? '');
if ($file === '' || !file_exists($file)) {
    exit(0);
}
$rel = rel_path($file, $project);
$lower = strtolower($rel);

// Remember edited files for the end-of-turn sweep.
@file_put_contents(edits_log($project), $rel . PHP_EOL, FILE_APPEND);

$problems = [];

if (str_ends_with($lower, '.php')) {
    [$code, $out] = run(['php', '-l', $file], $project);
    if ($code !== 0) {
        $problems[] = "php -l failed for $rel:\n$out";
    }
    // Hard rules from the MedLink skill.
    $src = (string) file_get_contents($file);
    if (preg_match("#regex:/\\^09\\[0-9\\]\\{9\\}\\$/#", $src)) {
        $problems[] = "$rel still uses the copied 09-only regex. Use new PhilippineMobile (P1 rule).";
    }
    if (preg_match('/Log::\w+\([^;]*\$code\b/', $src) && !str_contains($lower, 'otpservice')) {
        $problems[] = "$rel appears to log an OTP code. Only OtpService's local fallback may do that.";
    }
    if (preg_match('/env\(\s*[\'"]HTTPSMS_API_KEY/', $src) && !str_starts_with($lower, 'config/')) {
        $problems[] = "$rel reads HTTPSMS_API_KEY with env(). Use config('services.httpsms.api_key').";
    }
}

if (str_starts_with($lower, 'database/migrations/') && str_ends_with($lower, '.php')) {
    [$code, $out] = run(['php', 'artisan', 'migrate', '--pretend', '--no-interaction'], $project);
    if ($code !== 0) {
        $problems[] = "php artisan migrate --pretend failed after editing $rel:\n" . substr($out, -2000);
    }
}

if (preg_match('/\.(js|mjs)$/', $lower) && !str_starts_with($lower, 'public/build/')) {
    [$code, $out] = run(['node', '--check', $file], $project);
    if ($code !== 0) {
        $problems[] = "node --check failed for $rel:\n$out";
    }
}

if ($problems) {
    block_with("MedLink post-edit check FAILED. Fix before continuing:\n\n" . implode("\n\n", $problems));
}
exit(0);
