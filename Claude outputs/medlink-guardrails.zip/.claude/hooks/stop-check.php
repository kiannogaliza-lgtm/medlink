<?php
// Stop: end-of-turn sweep over every file edited this session.
// If anything fails, Claude is told to keep working instead of stopping.
require __DIR__ . '/_lib.php';

$in = hook_input();
if (!empty($in['stop_hook_active'])) {
    exit(0); // already re-running after a failed sweep; avoid loops
}
$project = project_dir($in);
$log = edits_log($project);
if (!is_file($log)) {
    exit(0);
}
$files = array_values(array_unique(array_filter(array_map('trim', file($log)))));
if (!$files) {
    exit(0);
}

$problems = [];
$routesTouched = false;
$frontendTouched = false;

foreach ($files as $rel) {
    $abs = $project . '/' . $rel;
    if (!is_file($abs)) {
        continue;
    }
    $lower = strtolower($rel);
    if (str_ends_with($lower, '.php')) {
        [$code, $out] = run(['php', '-l', $abs], $project);
        if ($code !== 0) {
            $problems[] = "php -l: $out";
        }
    }
    if ($lower === 'routes/web.php') {
        $routesTouched = true;
    }
    if (str_starts_with($lower, 'resources/js/') || str_ends_with($lower, '.vue')) {
        $frontendTouched = true;
    }
}

if ($routesTouched) {
    [$code, $out] = run(['php', 'artisan', 'route:list', '--no-interaction'], $project);
    if ($code !== 0) {
        $problems[] = "php artisan route:list failed:\n" . substr($out, -1500);
    }
}

if ($frontendTouched) {
    [$code, $out] = run(['npm', 'run', 'build'], $project);
    if ($code !== 0) {
        $problems[] = "npm run build failed:\n" . substr($out, -2000);
    }
}

if ($problems) {
    block_with("MedLink end-of-turn sweep FAILED. Fix these, then summarize:\n\n" . implode("\n\n", $problems));
}

// Clean sweep: reset the edit list so the next turn starts fresh.
@unlink($log);
fwrite(STDERR, 'MedLink sweep OK: ' . count($files) . " file(s) checked.\n");
exit(0);
