<?php
// PreToolUse (Edit|Write|MultiEdit|NotebookEdit): approval gate for every file write.
require __DIR__ . '/_lib.php';

$in = hook_input();
$project = project_dir($in);
$file = (string) ($in['tool_input']['file_path'] ?? $in['tool_input']['notebook_path'] ?? '');
$rel = rel_path($file, $project);
$lower = strtolower($rel);
$exists = $file !== '' && file_exists($file);

// ---------- DENY ----------
if (preg_match('#(^|/)\.env(\..+)?$#', $lower) && !str_ends_with($lower, '.env.example')) {
    decide('deny', 'BLOCKED: .env files hold secrets. Edit them yourself.');
}
if (str_starts_with($lower, 'vendor/') || str_starts_with($lower, 'node_modules/') || str_starts_with($lower, 'public/build/')) {
    decide('deny', 'BLOCKED: generated/vendor files are never edited by hand.');
}
if (str_starts_with($lower, 'storage/app/') || str_starts_with($lower, 'public/storage/')) {
    decide('deny', 'BLOCKED: user uploads (ID photos, proof photos) are never written by the agent.');
}
if (str_starts_with($lower, '.claude/hooks/') || $lower === '.claude/settings.json') {
    decide('deny', 'BLOCKED: the agent may not change its own guardrails.');
}

// ---------- ASK with a specific warning ----------
if (str_starts_with($lower, 'database/migrations/') && $exists) {
    decide('ask', "EDITING AN EXISTING MIGRATION ($rel). House rule: never edit an old migration; create a new one. Approve only if this migration has NOT been run yet.");
}
if (str_starts_with($lower, 'database/migrations/')) {
    decide('ask', "NEW MIGRATION: $rel. After approval the post-edit check runs `php artisan migrate --pretend`.");
}
if ($lower === 'phpunit.xml') {
    decide('ask', 'phpunit.xml: tests must keep DB_CONNECTION=sqlite and DB_DATABASE=:memory:.');
}
if (str_ends_with($lower, '.sql')) {
    decide('ask', "SQL FILE WRITE: $rel");
}
if ($lower === 'routes/web.php' || str_starts_with($lower, 'config/')) {
    decide('ask', "ROUTES/CONFIG WRITE: $rel");
}

// ---------- ASK for every other write ----------
decide('ask', ($exists ? 'EDIT' : 'CREATE') . ": $rel");
