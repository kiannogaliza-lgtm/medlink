<?php
// MedLink agent guardrails - shared helpers for Claude Code hooks.
// Hooks receive one JSON object on stdin and answer on stdout/stderr.

function hook_input(): array
{
    $raw = stream_get_contents(STDIN);
    $data = json_decode($raw ?: '{}', true);
    return is_array($data) ? $data : [];
}

function project_dir(array $in): string
{
    $dir = getenv('CLAUDE_PROJECT_DIR') ?: ($in['cwd'] ?? getcwd());
    return rtrim(str_replace('\\', '/', $dir), '/');
}

/** PreToolUse decision: 'allow' | 'ask' | 'deny'. */
function decide(string $decision, string $reason): never
{
    echo json_encode([
        'hookSpecificOutput' => [
            'hookEventName' => 'PreToolUse',
            'permissionDecision' => $decision,
            'permissionDecisionReason' => $reason,
        ],
    ], JSON_UNESCAPED_SLASHES);
    exit(0);
}

/** Feed a problem back to Claude (PostToolUse / Stop) so it fixes it. */
function block_with(string $message): never
{
    fwrite(STDERR, $message . PHP_EOL);
    exit(2);
}

function rel_path(string $file, string $project): string
{
    $file = str_replace('\\', '/', $file);
    $p = strtolower($project) . '/';
    return str_starts_with(strtolower($file), $p) ? substr($file, strlen($p)) : ltrim($file, './');
}

/** Newest *.sql backup age in minutes, or null if none. */
function newest_backup_minutes(): ?float
{
    $dir = getenv('MEDLINK_BACKUP_DIR') ?: 'C:/laragon-backups';
    $files = glob(rtrim($dir, '/\\') . '/*.sql') ?: [];
    if (!$files) {
        return null;
    }
    $newest = max(array_map('filemtime', $files));
    return (time() - $newest) / 60;
}

function edits_log(string $project): string
{
    return $project . '/.claude/hooks/.session-edits';
}

/**
 * Run a program WITHOUT a shell (argv array -> no injection).
 * npm on Windows is a .cmd shim, so it is routed through cmd /c with fixed arguments.
 * @return array{0:int,1:string} exit code, combined output
 */
function run(array $argv, string $cwd): array
{
    if (PHP_OS_FAMILY === 'Windows' && in_array($argv[0], ['npm', 'npx'], true)) {
        $argv = array_merge(['cmd', '/c'], $argv);
    }
    $spec = [1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
    $proc = @proc_open($argv, $spec, $pipes, $cwd);
    if (!is_resource($proc)) {
        return [127, 'Could not start: ' . $argv[0]];
    }
    $out = stream_get_contents($pipes[1]) . stream_get_contents($pipes[2]);
    fclose($pipes[1]);
    fclose($pipes[2]);
    return [proc_close($proc), trim($out)];
}
