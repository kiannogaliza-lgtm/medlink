<?php
// PreToolUse (Bash): database + destructive command gate for MedLink.
// deny  = never allowed for the agent (you run it yourself)
// ask   = you approve each time (with the reason shown)
// allow = read-only checks run without prompting
require __DIR__ . '/_lib.php';

$in = hook_input();
$cmd = trim((string) ($in['tool_input']['command'] ?? ''));
$c = strtolower(preg_replace('/\s+/', ' ', $cmd));

// ---------- DENY: data-destroying or secret-leaking ----------
$deny = [
    '/artisan\s+(migrate:(fresh|refresh|reset)|db:wipe)/' => 'Wipes or rebuilds the database. Run it yourself after a backup if you really mean it.',
    '/\b(drop\s+(database|schema|table)|truncate\s+(table\s+)?\w)/' => 'DROP/TRUNCATE is not allowed from the agent.',
    '/(^|[\s;&|])(cat|type|more|less|head|tail|get-content|gc)\s+[^;&|]*\.env(\s|$)/' => '.env holds secrets; read key names only via the skill rules.',
    '/artisan\s+(env|config:show)\b/' => 'May print secret values.',
    '/\bgit\s+push\b/' => 'Pushing is your call, not the agent\'s.',
    '/\b(rm|del|erase|rmdir|remove-item)\b[^;&|]*(storage[\\\\\/]app|public[\\\\\/]storage|database[\\\\\/]migrations|\.env)/' => 'Deleting uploads, migrations or .env is not allowed.',
];
foreach ($deny as $re => $why) {
    if (preg_match($re, $c)) {
        decide('deny', "BLOCKED by MedLink guard: $why");
    }
}

// ---------- ALLOW: read-only / safe checks ----------
$allow = [
    '/^php\s+-l\s/',
    '/^php\s+artisan\s+migrate\s+--pretend\b/',
    '/^php\s+artisan\s+(migrate:status|route:list|about|list|view:clear|config:clear|cache:clear)\b/',
    '/^node\s+--check\s/',
    '/^(npm\s+run\s+build|npx\s+vite\s+build)\b/',
    '/^(git\s+(status|diff|log|show)\b)/',
    '/^(ls|dir|pwd|grep|rg|findstr|wc)\b/',
];
foreach ($allow as $re) {
    if (preg_match($re, $c) && !preg_match('/[;&|>]/', $c)) {
        decide('allow', 'MedLink guard: read-only check.');
    }
}

// ---------- Tests: only against the in-memory SQLite DB ----------
if (preg_match('/(artisan\s+test|vendor[\\\\\/]bin[\\\\\/](phpunit|pest)|\bphpunit\b)/', $c)) {
    $xml = @file_get_contents(project_dir($in) . '/phpunit.xml') ?: '';
    $sqlite = preg_match('/name="DB_CONNECTION"\s+value="sqlite"/', $xml)
        && preg_match('/name="DB_DATABASE"\s+value=":memory:"/', $xml);
    if (!$sqlite) {
        decide('deny', 'BLOCKED: phpunit.xml no longer forces DB_CONNECTION=sqlite + DB_DATABASE=:memory:. Tests would hit the real MySQL database.');
    }
    decide('allow', 'MedLink guard: tests run on SQLite :memory:.');
}

// ---------- ASK: anything that writes to the database ----------
if (preg_match('/artisan\s+migrate(\s|$)(?!.*--pretend)/', $c) || preg_match('/artisan\s+migrate:rollback/', $c)) {
    $age = newest_backup_minutes();
    if ($age === null || $age > 60) {
        decide('deny', 'BLOCKED: no database backup newer than 60 minutes in C:/laragon-backups. Back up first: cmd /c "mysqldump -u root <db> > C:\\laragon-backups\\medlink_<date>.sql", then retry.');
    }
    decide('ask', sprintf('DATABASE WRITE: %s  (latest backup %d min old). Approve only if you reviewed `migrate --pretend`.', $cmd, (int) $age));
}
if (preg_match('/artisan\s+(db:seed|tinker|queue:work|schedule:run|otp:|sms:)/', $c) || preg_match('/artisan\s+migrate:install/', $c)) {
    decide('ask', "DATABASE / SIDE-EFFECT COMMAND: $cmd");
}
if (preg_match('/\b(mysql|mariadb|heidisql)(\.exe)?\b/', $c) && !preg_match('/\bmysqldump\b/', $c)) {
    $danger = preg_match('/\b(insert|update|delete|alter|create|replace|grant)\b/', $c) ? ' Contains a WRITE statement.' : '';
    decide('ask', "DIRECT DATABASE ACCESS: $cmd.$danger");
}

// ---------- ASK: other writes / side effects ----------
if (preg_match('/\bgit\s+(commit|reset|checkout|restore|clean|stash|rebase|merge)\b/', $c)) {
    decide('ask', "GIT CHANGE: $cmd");
}
if (preg_match('/\b(rm|del|erase|rmdir|remove-item|mv|move|move-item|copy|cp|ren|rename)\b/', $c)
    || preg_match('/(composer|npm)\s+(install|require|update|remove|uninstall|i)\b/', $c)
    || preg_match('/(^|[^>])>{1,2}\s*\S/', $c)
    || preg_match('/\b(sed\s+-i|set-content|out-file|add-content)\b/', $c)
    || preg_match('/\bcurl\b.*(-x\s*(post|put|delete)|--data|-d\s)/', $c)) {
    decide('ask', "FILE / PACKAGE / NETWORK WRITE: $cmd");
}

// Everything else: fall through to normal Claude Code permission rules.
exit(0);
